/*import { Component, OnInit } from '@angular/core';
import { FileSelectDirective, FileUploader} from 'ng2-file-upload';
//import { FileService } from './file.service';
import {saveAs} from 'file-saver';

const uri = 'http://localhost:1128/uploadFile/api/file/upload/uploadfile';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent  {

  //constructor() { }

  //ngOnInit(): void {
  //}

  uploader:FileUploader = new FileUploader({url:uri});

  attachmentList:any = [];
  fileService: any;

  constructor(){
    this.uploader.onCompleteItem=(item:any, response:any, status:any, headers:any)=>{
      this.attachmentList.push(JSON.parse(response));
    }
  }
  download(index){
    var filename = this.attachmentList[index].uploadname;

    this.fileService.downloadFile(filename)
    .subscribe(
        data => saveAs(data, filename),
        error => console.error(error)
    );
}
}*/

import { HttpClient, HttpEventType } from '@angular/common/http';
import { Component } from '@angular/core';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
})
export class EmployeeComponent {
  [x: string]: any;
  constructor(private httpClient: HttpClient) { }
  selectedFile: File;
  retrievedImage: any;
  base64Data: any;
  retrieveResonse: any;
  message: string;
  fileId: any;
  resultFile:any;
  //Gets called when the user selects an image
  public onFileChanged(event) {
    //Select File
    this.selectedFile = event.target.files[0];
  }
  //Gets called when the user clicks on submit to upload the image
  onUpload() {
    console.log(this.selectedFile);

    //FormData API provides methods and properties to allow us easily prepare form data to be sent with POST HTTP requests.
    const uploaddatafile = new FormData();
    uploaddatafile.append('File', this.selectedFile, this.selectedFile.name);

    //Make a call to the Spring Boot Application to save the image
    this.httpClient.post('http://localhost:1128/upload', uploaddatafile, { observe: 'response' })
      .subscribe((response) => {
        if (response.status===200) {
          this.message = 'file uploaded successfully';

        } else {
          this.message = 'file not uploaded successfully';
        }
      }
      );
  }
     // this.httpClient.get('http://localhost:1128/api/file/' + this.fileId + '.txt', {responseType: 'text'})
       // .subscribe(data => console.log(data));

  }

  /*getFile() {
    this.fileService.getFile('http://localhost:1128/api/file/' + this.fileId +'.txt').subscribe(file => {
    this.resultFile = file;
    console.log(this.resultFile);
    });
    }*/
