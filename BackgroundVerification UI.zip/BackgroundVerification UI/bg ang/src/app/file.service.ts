import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Injectable } from "@angular/core";


@Injectable({
  providedIn: 'root'
})
export class FileService {

  constructor(private _http:HttpClient) { }
  UserId: any;
  up: Verification;
  public addVer(setVer: Verification) {
    console.log("ins service add");
    console.log(setVer);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this._http.post("http://localhost:1128/ver/addVer", setVer,  { headers, responseType: 'text'});
  }

  public checkStatus(){
    console.log("ins service get status");
    const headers=new HttpHeaders().set('Content_Type','text/plain ;charset=utf-8');
    return this._http.get("http://localhost:1128/ver/checkStatus/" +this.UserId);
  }

}
export class Verification{
  VerificationId:number;
  Status:String;
  UserId:number;
  DocId:number;
}
