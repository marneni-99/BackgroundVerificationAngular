import { Component, OnInit } from '@angular/core';
import { Verification, FileService } from '../file.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ver',
  templateUrl: './ver.component.html',
  styleUrls: ['./ver.component.css']
})
export class VerComponent implements OnInit {

  constructor(private ser:FileService,private router:Router) { }

  ngOnInit(): void {
  }
    onSubmit(setVer:Verification):any{
      console.log(setVer);
       this.ser.addVer(setVer).subscribe(data => {
        });
    }

}
