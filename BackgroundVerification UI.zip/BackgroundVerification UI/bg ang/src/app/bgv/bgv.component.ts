/*import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bgv',
  templateUrl: './bgv.component.html',
  styleUrls: ['./bgv.component.css']
})
export class BgvComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}*/
import { HttpClient, HttpEventType } from '@angular/common/http';
import { Component } from '@angular/core';
@Component({
  selector: 'app-bgv',
  templateUrl: './bgv.component.html',
  styleUrls: ['./bgv.component.css'],
})
export class BgvComponent {
  [x: string]: any;
  constructor(private httpClient: HttpClient) { }
  selectedFile: File;
  retrievedImage: any;
  base64Data: any;
  retrieveResonse: any;
  message: string;
  fileId: any;
  resultFile:any;
  //Gets called when the user selects an image
  public onFileChanged(event) {
    //Select File
    this.selectedFile = event.target.files[0];
  }
  //Gets called when the user clicks on submit to upload the image
    //Gets called when the user clicks on retieve image button to get the image from back end
    getImage() {
    //Make a call to Sprinf Boot to get the Image Bytes.
   this.httpClient.get('http://localhost:1128/get/' + this.fileId)
      .subscribe(
        res => {
          this.retrieveResonse = res;
          this.base64Data = this.retrieveResonse.pic;
          this.retrievedImage = 'data:image/jpeg;base64,' + this.base64Data;
        }

      );
    }

    loadVer(){
      this.router.navigate(['app-ver']);
    }
  }
